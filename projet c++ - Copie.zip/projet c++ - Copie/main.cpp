#include <iostream>
#include <graphics.h>
#include "fenetres.h"
#include "figure.h"
#include "dessin.h"
#include <cmath>

using namespace std ;

int main(int argc , char** argv) {
	
	fenetres f ; // creation d'une nouvelle fenetre 
	int x , y ;// x=abscisse , y=ordonn� 
	f.ouvrir_graphique() ;//pour ouvrir la fenetre f cre�
	x = f.get_x_max()/2 ;//on donne a x par defaut le centre de la fentre 
	y = f.get_y_max()/2 ;// meme chese que x
	f.allume(x , y , f.get_couleur_fond()+10) ;
	delay(1000) ; //pour ralentir l'execution du programme
	//f.fermer_graphique() ;
	
	figure fc ;//creation de la figure cercle fc
	fc.set_cercle(x,60,50,10) ;//pour definir le type
	fc.dessiner() ;
	delay(500) ;	
	figure fr ;//creation de la figure rectangle fr
	fr.set_rectangle(x,140,50,100,10) ;//donner le type
	fr.dessiner() ;
	delay(500) ;	
	figure fmdr ; //pour creer la main droite
	fmdr.set_droite(fr.get_x_min()-30 , fr.get_y_min()+30 ,60,-30 , 10) ;
	fmdr.dessiner() ;
	figure fmg ;//creation main gauche
	fmg.set_droite(fr.get_x_max()+30 , fr.get_y_min()+30 ,60,30 ,10) ;
	fmg.dessiner() ;
	delay(500) ;
	figure fpdr ; //creer pied droite
	fpdr.set_droite(fr.get_x_min()+5 , fr.get_y_max()+40 ,0,80,10) ;
	fpdr.dessiner() ;
	figure fpg ; //creer pied gauche
	fpg.set_droite(fr.get_x_max()-5 , fr.get_y_max()+40 ,0,80 , 10) ;
	fpg.dessiner() ;	
	delay(1000) ;
	
	dessin bonhomme ;

	bonhomme.t[0]=fc ;
	bonhomme.t[1]=fr ;
	bonhomme.t[2]=fmdr ;
	bonhomme.t[3]=fmg ;
	bonhomme.t[4]=fpdr ;
	bonhomme.t[5]=fpg ;
	
	delay(1000) ;
		delay(1000) ;
		
	bonhomme.deplacementBonhomme(250,220,f) ;
		
	double X, Y, A ;//A=angle
	const double pi = acos(-1.0) ;
    double r = y-250 ;
    X = y/2 ;
    for (int i = 0; i<360*5; i++) {
        int X2=X , Y2=Y ;
        A = i*(pi/180.0) ;
        X = int(r*sin(A)) ;
        Y = int(r*cos(A)) ;
        bonhomme.deplacementBonhomme(X-X2,Y-Y2,f) ;
        delay(15) ;
    }
	
	delay(5000) ;

	return 0 ;
}
