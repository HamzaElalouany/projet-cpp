#include "figure.h"
#ifndef DESSIN_H
#define DESSIN_H

class dessin {
	public :
		figure t[100] ;
		int nbrf;
		
		dessin() {
			this->nbrf = 25 ;
		}
		
		void deplacementBonhomme(int dx,int dy,fenetres f) {
 			for(int i=0;i<this->nbrf;i++) 
				this->t[i].deplacer(dx,dy,f) ;
		}
};

#endif
